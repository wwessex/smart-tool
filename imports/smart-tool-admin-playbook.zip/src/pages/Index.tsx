import { SmartActionTool } from '@/components/smart/SmartActionTool';

const Index = () => {
  return <SmartActionTool />;
};

export default Index;
