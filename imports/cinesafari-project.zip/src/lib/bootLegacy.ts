import { SHELL_HTML } from "../legacy/shell";

/**
 * Boots the legacy DOM-driven app once.
 * Keeps StrictMode + HMR from double-starting the legacy code.
 *
 * Phase 3 (hotfix): waits for the legacy HTML shell to exist before importing the legacy runtime,
 * and supports ?nosw=1 for bypassing/clearing service worker caches during recovery.
 */

const REQUIRED_IDS = [
  "card-grid",
  "search-form",
  "search-input",
  "section-title",
  "section-subtitle",
  "controls-bar",
  "menu-toggle",
  "menu-overlay",
  "bottom-nav",
] as const;

async function maybeBypassServiceWorker(): Promise<void> {
  try {
    const sp = new URLSearchParams(window.location.search);
    const nosw = sp.get("nosw");
    if (!nosw) return;

    // If user explicitly asked to bypass SW, unregister and clear caches best-effort.
    if ("serviceWorker" in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister().catch(() => false)));
    }
    if ("caches" in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k).catch(() => false)));
    }
  } catch {
    // ignore
  }
}

function ensureShellInjected(): void {
  // If React rendered the container but innerHTML didn't land (host/CMS scripts can interfere),
  // inject the shell directly as a fallback. This keeps behaviour identical: same SHELL_HTML.
  const shell = document.getElementById("cinesafari-shell");
  if (!shell) return;
  if (shell.childElementCount > 0) return;
  try {
    shell.innerHTML = SHELL_HTML;
  } catch {
    // ignore
  }
}

function allRequiredDomPresent(): boolean {

  // Shell container should exist and have children
  const shell = document.getElementById("cinesafari-shell");
  if (!shell || shell.childElementCount === 0) return false;

  for (const id of REQUIRED_IDS) {
    if (!document.getElementById(id)) return false;
  }
  return true;
}

async function waitForShell(timeoutMs = 6000): Promise<void> {
  const start = performance.now();
  // Try a few frames in case React hasn't flushed innerHTML yet on slower devices.
  while (performance.now() - start < timeoutMs) {
    try { ensureShellInjected(); } catch (e) {}
    if (allRequiredDomPresent()) return;
    await new Promise((r) => requestAnimationFrame(() => r(null)));
  }
  // One last check
  if (allRequiredDomPresent()) return;

  const missing = REQUIRED_IDS.filter((id) => !document.getElementById(id));
  throw new Error(
    "CineSafari can’t start (missing DOM elements)\n\n" +
      "These element IDs are missing from the page:\n\n" +
      missing.map((m) => "• " + m).join("\n") +
      "\n\nThis usually happens if the HTML shell didn’t deploy correctly, " +
      "or if a CMS/rewrite replaced index.html.\n\n" +
      "Fix: upload the contents of the Vite dist/ folder (including assets/), then open once with ?nosw=1."
  );
}

export async function bootLegacyOnce(): Promise<void> {
  if (window.__CS_LEGACY_BOOTED__) return;
  window.__CS_LEGACY_BOOTED__ = true;

  try {
    await maybeBypassServiceWorker();
    await waitForShell();

    // Vite will pick legacy-app.js via extensionless import.
    await import("../legacy/legacy-app");
  } catch (err) {
    // Last-resort visible error
    const details =
      err && typeof err === "object" && "stack" in err && (err as any).stack
        ? String((err as any).stack)
        : err && typeof err === "object" && "message" in err && (err as any).message
        ? String((err as any).message)
        : String(err);

    const pre = document.createElement("pre");
    pre.style.whiteSpace = "pre-wrap";
    pre.style.padding = "16px";
    pre.style.margin = "16px";
    pre.style.borderRadius = "12px";
    pre.style.border = "1px solid rgba(148,163,184,.25)";
    pre.style.background = "rgba(17,24,39,.65)";
    pre.style.color = "#f9fafb";
    pre.textContent = `CineSafari failed to start.\n\n${details}`;
    document.body.innerHTML = "";
    document.body.appendChild(pre);
  }
}
