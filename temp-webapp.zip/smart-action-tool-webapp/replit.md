# SMART Action Support Tool

## Overview
A modern, offline-capable web application for generating consistent SMART actions for barriers to action. This is a static frontend application with HTML, CSS, and JavaScript. Used by Restart Advisors for employability support.

## SMART Framework (Restart Advisors Format)
Generated actions follow the SMART framework:
- **S - Specific**: Exactly what will you do?
- **M - Measurable**: How will you know it's done?
- **A - Achievable**: Is it realistic with their current situation?
- **R - Relevant**: Does it link to their job goal and barriers?
- **T - Time-bound**: By when? (clear date/time)

Actions are formatted as: "As discussed and agreed, [Name] will [action]..."

## Project Structure
- `index.html` - Main HTML file with the application UI
- `app.js` - Main application JavaScript logic
- `ai-worker.js` - AI worker for on-device draft generation
- `data.js` - Data definitions, barriers list, and SMART builder phrases
- `styles.css` - Application styles
- `sw.js` - Service worker for offline capability
- `server.js` - Simple Node.js static file server for development
- `assets/` - Icons and images
- `manifest.webmanifest` - PWA manifest file

## Development
The application runs on a simple Node.js static file server:
- Host: 0.0.0.0
- Port: 5000

Run with: `node server.js`

## Deployment
Configured for static deployment serving files from the root directory.

## Features
- Generate SMART actions for barriers to action (now or in future)
- Offline-capable (PWA)
- AI draft generation (runs on-device) - replaces content on each use
- Export functionality (copy, download as text)
- History tracking for saved actions

## Recent Changes
- Redesigned Task-based tab for scheduling FUTURE activities (not past)
  - Updated all labels to future tense: "Scheduled date", "What will happen / expected outcome?"
  - Added intro text: "Schedule a future task, event, or activity for the participant."
  - Output now reads: "On [date], [Name] will attend [task]. [Outcome]. This will be reviewed..."
  - AI assist with category-specific suggestions (job fair, workshop, interview, CV, application)
  - Smart outcome formatting: auto-prefixes "[Name] will" for verb phrases
- Added 12 UX/accessibility improvements:
  - Form validation highlighting (red/green visual feedback on incomplete fields)
  - Keyboard shortcuts: Ctrl+Enter to generate, Ctrl+Shift+C to copy
  - Recent participant names autofill (datalist populated from localStorage)
  - Copy-to-clipboard animation feedback (.copied class)
  - Edit button on history items restores all form fields and output text
  - History search/filter by forename, barrier, or text content
  - CSV export for history with proper escaping
  - Print-friendly styling (@media print)
  - Improved touch targets (44px minimum for mobile)
  - ARIA live regions for screen reader announcements
  - Focus management when switching tabs
  - Validation clears on tab switch and form clear
- Added 7 new barrier categories to ACTION_LIBRARY:
  - Mental Wellbeing, Digital Skills, Communication Skills
  - Caring Responsibilities, Qualifications, Job Goal
- Service worker version updated to v10 with optimised caching
- Fixed AI draft duplicate text issue (now replaces instead of appends)
- Updated generated action format to use "As discussed and agreed, [Name] will..." format
- Split date validation: dateHintNow (warns if not today) and dateHintFuture (warns if past)
- Task-based date input now allows future dates only (min=today)
- Expanded formatTaskOutcome verb whitelist to 40+ common verbs
- buildFutureSuggestionList requires forename to prevent "[Name]" placeholder leaks
- bestTaskSuggestion fallback now uses future-tense outcomes
