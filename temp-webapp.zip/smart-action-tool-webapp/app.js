// NOTE: Classic-script build for maximum iOS Safari compatibility (no ES modules).
// Data is provided by data.js which attaches constants on window.
const DEFAULT_BARRIERS = window.DEFAULT_BARRIERS || [];
const DEFAULT_TIMESCALES = window.DEFAULT_TIMESCALES || [];
const BUILDER_NOW = window.BUILDER_NOW || {};
const BUILDER_TASK = window.BUILDER_TASK || {};
const GUIDANCE = window.GUIDANCE || {};
const ACTION_LIBRARY = window.ACTION_LIBRARY || {};
const FALLBACK_SUGGESTIONS = window.FALLBACK_SUGGESTIONS || [];

const $ = (id) => document.getElementById(id);

// Debounce utility for performance
function debounce(fn, delay = 150) {
  let timer;
  return function(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

const STORAGE = {
  barriers: "smartTool.barriers",
  timescales: "smartTool.timescales",
  history: "smartTool.history",
  experimentalModel: "smartTool.experimentalModel",
  recentNames: "smartTool.recentNames"
};

// Screen reader announcement helper
function announce(msg) {
  const el = document.getElementById("srAnnounce");
  if (el) {
    el.textContent = "";
    setTimeout(() => { el.textContent = msg; }, 50);
  }
}

// Recent names management
function getRecentNames() {
  try {
    const raw = localStorage.getItem(STORAGE.recentNames);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function addRecentName(name) {
  if (!name || !name.trim()) return;
  const trimmed = name.trim();
  let names = getRecentNames().filter(n => n.toLowerCase() !== trimmed.toLowerCase());
  names.unshift(trimmed);
  names = names.slice(0, 10); // Keep last 10
  try { localStorage.setItem(STORAGE.recentNames, JSON.stringify(names)); } catch {}
  populateRecentNamesList();
}

function populateRecentNamesList() {
  const list = document.getElementById("recentNamesList");
  if (!list) return;
  const names = getRecentNames();
  list.innerHTML = "";
  names.forEach(n => {
    const opt = document.createElement("option");
    opt.value = n;
    list.appendChild(opt);
  });
}

const IS_IOS = /iphone|ipad|ipod/i.test(navigator.userAgent);

function getExperimentalModelEnabled(){
  try{ return localStorage.getItem(STORAGE.experimentalModel) === "1"; }
  catch{ return false; }
}

function setExperimentalModelEnabled(v){
  try{ localStorage.setItem(STORAGE.experimentalModel, v ? "1" : "0"); }
  catch{}
}

function localModelSupported(){
  // Keep iOS on the instant offline drafts (Safari limitations vary a lot).
  // Desktop browsers may attempt an on-device model when explicitly enabled.
  return !IS_IOS && typeof WebAssembly === "object";
}

const LOCAL_MODEL = {
  pipe: null,
  loading: null
};

// Avoid using the `import(...)` token directly in classic scripts.
// Some Safari builds throw a parse-time SyntaxError even if dynamic import
// is never invoked. Keep it behind a Function so iOS Safari can parse the file.
function safeDynamicImport(url){
  try{
    // eslint-disable-next-line no-new-func
    const fn = Function("u", "return import(u)");
    return fn(url);
  } catch (e) {
    return Promise.reject(e);
  }
}

async function getLocalModelPipe(){
  if(LOCAL_MODEL.pipe) return LOCAL_MODEL.pipe;
  if(LOCAL_MODEL.loading) return await LOCAL_MODEL.loading;

  // NOTE: this is optional/experimental. We always fall back to offline drafts.
  LOCAL_MODEL.loading = (async ()=>{
    const mod = await safeDynamicImport("https://cdn.jsdelivr.net/npm/@xenova/transformers");
    const pipe = await mod.pipeline("text2text-generation", "Xenova/flan-t5-small", { quantized: true });
    LOCAL_MODEL.pipe = pipe;
    return pipe;
  })();
  return await LOCAL_MODEL.loading;
}

function todayISO(){
  const d = new Date();
  const tz = d.getTimezoneOffset();
  // normalize to local date
  const local = new Date(d.getTime() - tz*60000);
  return local.toISOString().slice(0,10);
}
function formatDDMMMYY(iso){
  // Excel: DD-MMM-YY, e.g. 13-Jan-26
  const d = new Date(iso + "T00:00:00");
  const dd = String(d.getDate()).padStart(2,"0");
  const mmm = d.toLocaleString("en-GB", { month: "short" });
  const yy = String(d.getFullYear()).slice(-2);
  return `${dd}-${mmm}-${yy}`;
}

// --- Advisor assist (mixed strategy) ---------------------------------------

function parseTimescaleToTargetISO(baseISO, timescale){
  // baseISO: YYYY-MM-DD (local)
  const d = new Date(baseISO + "T00:00:00");
  const t = (timescale || "").trim().toLowerCase();
  if(!t) return baseISO;

  // Weeks
  const w = t.match(/^(\d+)\s*week/);
  if(w){
    const days = parseInt(w[1],10) * 7;
    d.setDate(d.getDate() + days);
    return d.toISOString().slice(0,10);
  }
  // Months
  const m = t.match(/^(\d+)\s*month/);
  if(m){
    const months = parseInt(m[1],10);
    const day = d.getDate();
    d.setMonth(d.getMonth() + months);
    // naive "end of month" guard: if month rolled, clamp
    if(d.getDate() < day){
      d.setDate(0);
    }
    return d.toISOString().slice(0,10);
  }
  return baseISO;
}

function pickLibraryKey(barrier){
  const b = (barrier || "").trim().toLowerCase();
  if(!b) return "";
  const keys = Object.keys(ACTION_LIBRARY);
  // exact match (case-insensitive)
  for(const k of keys){
    if(k.toLowerCase() === b) return k;
  }
  // contains match (helps if user types extra words)
  for(const k of keys){
    const kl = k.toLowerCase();
    if(b.includes(kl)) return k;
  }
  return "";
}

function resolvePlaceholders(str, ctx){
  return (str || "")
    .replaceAll("{targetDate}", ctx.targetPretty)
    .replaceAll("{n}", String(ctx.n ?? 2));
}

function buildNowSuggestionList(){
  const barrierKey = pickLibraryKey(els.nowBarrier.value);
  const raw = barrierKey ? (ACTION_LIBRARY[barrierKey] || []) : [];
  const list = raw.length ? raw : FALLBACK_SUGGESTIONS;

  const baseISO = els.nowDate.value || todayISO();
  const targetISO = parseTimescaleToTargetISO(baseISO, els.nowTimescale.value);
  const ctx = {
    targetPretty: formatDDMMMYY(targetISO),
    n: 2
  };

  const q = (els.nowSuggestQuery.value || "").trim().toLowerCase();
  const filtered = !q ? list : list.filter(s => 
    (s.title||"").toLowerCase().includes(q) ||
    (s.action||"").toLowerCase().includes(q) ||
    (s.help||"").toLowerCase().includes(q)
  );

  // Use DocumentFragment for batch DOM update (reduces reflows)
  const fragment = document.createDocumentFragment();
  for(const s of filtered.slice(0, 14)){
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "chip";
    btn.innerHTML = `<span>${escapeHtml(s.title)}</span><span class="tag">insert</span>`;
    btn.addEventListener("click", ()=>{
      const action = resolvePlaceholders(s.action, ctx);
      const help = resolvePlaceholders(s.help, ctx);

      if(!els.nowAction.value.trim()) els.nowAction.value = action;
      else els.nowAction.value = els.nowAction.value.trimEnd() + "\n" + action;

      if(help && !els.nowHelp.value.trim()) els.nowHelp.value = help;
      renderOutput(false);
      toast("Inserted suggestion.");
    });
    fragment.appendChild(btn);
  }
  els.nowSuggestList.innerHTML = "";
  els.nowSuggestList.appendChild(fragment);
}


// --- AI Draft (mixed strategy, offline-first) -----------------------------
//
// To keep this tool upload-and-go (static hosting) and reliable on iOS Safari,
// the “AI draft” button uses an offline heuristic generator:
//
// 1) Picks a best-fit curated suggestion from ACTION_LIBRARY (or fallback list)
// 2) Fills placeholders like {targetDate} and {n}
// 3) Converts the imperative into “{Forename} will …” so it reads like a SMART action
//
// This delivers immediate value with zero downloads and no external services.
// (You can still expand the curated library in data.js over time.)

async function localModelDraftNow({ forename, barrier, responsible, targetPretty }){
  const pipe = await getLocalModelPipe();
  const prompt = [
    "Write a short, professional SMART-style draft for an advisor case note. Use British English spelling and grammar.",
    `Participant forename: ${forename}`,
    `Barrier: ${barrier}`,
    `Responsible: ${responsible || "Participant"}`,
    `Deadline: ${targetPretty}`,
    "Output EXACTLY two lines:",
    "ACTION: <one sentence starting with the participant's name>",
    "HELP: <short phrase that fits after 'This action will help ...'>"
  ].join("\n");

  const out = await pipe(prompt, { max_new_tokens: 96 });
  const text = String(out?.[0]?.generated_text || "").trim();

  const lines = text.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  const actionLine = lines.find(l => /^ACTION\s*:/i.test(l));
  const helpLine = lines.find(l => /^HELP\s*:/i.test(l));
  const action = actionLine ? actionLine.replace(/^ACTION\s*:\s*/i, "").trim() : "";
  const help = helpLine ? helpLine.replace(/^HELP\s*:\s*/i, "").trim() : "";

  if(!action) throw new Error("Local model output missing ACTION");
  return { action, help };
}


function setAIStatus(el, msg, cls){
  el.textContent = msg || "";
  el.classList.remove("status-warn","status-ok","status-busy");
  if(cls) el.classList.add(cls);
}

function lowerFirstLetter(s){
  if(!s) return s;
  return s.charAt(0).toLowerCase() + s.slice(1);
}

function forenameWillify(action, forename){
  const a = (action || "").trim();
  const f = (forename || "").trim();
  if(!a) return "";
  if(!f) return a;
  // If it already starts with the name, leave it.
  if(a.toLowerCase().startsWith(f.toLowerCase())) return a;
  // Avoid double punctuation spacing etc.
  return `${f} will ${lowerFirstLetter(a)}`;
}

function bestNowSuggestion(barrier, q){
  const barrierKey = pickLibraryKey(barrier);
  let list = barrierKey ? (ACTION_LIBRARY[barrierKey] || []) : [];
  if(!list.length) list = FALLBACK_SUGGESTIONS;

  const query = (q || "").trim().toLowerCase();
  if(!query) return list[0];

  // Light scoring: prefer title match, then action, then help.
  let best = list[0];
  let bestScore = -1;
  for(const s of list){
    const t = (s.title||"").toLowerCase();
    const a = (s.action||"").toLowerCase();
    const h = (s.help||"").toLowerCase();
    let score = 0;
    if(t.includes(query)) score += 3;
    if(a.includes(query)) score += 2;
    if(h.includes(query)) score += 1;
    if(score > bestScore){
      bestScore = score;
      best = s;
    }
  }
  return best;
}


function pickTaskKey(taskDesc){
  const t = (taskDesc || "").trim().toLowerCase();
  if(!t) return "default";
  
  if(/job\s*fair|careers?\s*fair|recruitment\s*(event|fair)/i.test(t)) return "job fair";
  if(/workshop|session|group|course|training/i.test(t)) return "workshop";
  if(/interview|mock/i.test(t)) return "interview";
  if(/cv|resume|curriculum/i.test(t)) return "cv";
  if(/application|apply|applying/i.test(t)) return "application";
  
  return "default";
}

function bestTaskSuggestion(taskDesc){
  const key = pickTaskKey(taskDesc);
  const list = (typeof TASK_SUGGESTIONS !== "undefined" && TASK_SUGGESTIONS[key]) || TASK_SUGGESTIONS?.default || [];
  return list[0] || { title: "General activity", outcome: "[Name] will participate in this activity and identify next steps towards their employment goal." };
}

function buildFutureSuggestionList(){
  if(!els.futureSuggestList) return;
  const task = (els.futureBarrier.value || "").trim();
  
  const key = pickTaskKey(task);
  const suggestions = (typeof TASK_SUGGESTIONS !== "undefined" && TASK_SUGGESTIONS[key]) || TASK_SUGGESTIONS?.default || [];
  
  els.futureSuggestList.innerHTML = "";
  
  suggestions.forEach(s => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "suggest-btn";
    btn.innerHTML = `<span class="suggest-title">${s.title}</span> <span class="suggest-insert">insert</span>`;
    btn.onclick = () => {
      // Get forename at click time (not at build time) to always use latest value
      const forename = (els.futureForename.value || "").trim();
      if (!forename) {
        toast("Enter the participant's forename first.");
        els.futureForename.focus();
        return;
      }
      const outcome = s.outcome.replace(/\[Name\]/g, forename);
      els.futureReason.value = outcome;
      renderOutput(false);
      toast("Draft inserted.");
      announce("Draft inserted");
    };
    els.futureSuggestList.appendChild(btn);
  });
}

async function aiDraftFuture(){
  const task = (els.futureBarrier.value || "").trim();
  const forename = (els.futureForename.value || "").trim();

  if(!forename || !task){
    setAIStatus(els.futureAIStatus, "Add a forename and task description first.", "status-warn");
    toast("Add a forename and task description first.");
    return;
  }

  setAIStatus(els.futureAIStatus, "Drafting…", "status-busy");

  const s = bestTaskSuggestion(task);
  const outcome = s.outcome.replace(/\[Name\]/g, forename);

  els.futureReason.value = outcome;

  renderOutput(false);
  setAIStatus(els.futureAIStatus, "Draft inserted (edit the placeholders).", "status-ok");
  toast("Draft added. Edit the [placeholders].");
  announce("Draft inserted");
}

async function aiDraftNow(){
  const barrier = (els.nowBarrier.value || "").trim();
  const forename = (els.nowForename.value || "").trim();
  const responsible = (els.nowResponsible.value || "").trim();

  if(!forename || !barrier){
    setAIStatus(els.nowAIStatus, "Add a forename and select a barrier first.", "status-warn");
    toast("Add a forename and select a barrier first.");
    return;
  }

  const baseISO = els.nowDate.value || todayISO();
  let timescale = els.nowTimescale.value;
  if(!timescale){
    timescale = "2 weeks";
    els.nowTimescale.value = timescale;
  }
  const targetISO = parseTimescaleToTargetISO(baseISO, timescale);
  const ctx = { targetPretty: formatDDMMMYY(targetISO), n: 2 };

  setAIStatus(els.nowAIStatus, "Drafting…", "status-busy");

  // Optional experimental local model (desktop only). Always falls back to instant drafts.
  const useLocal = getExperimentalModelEnabled() && localModelSupported();
  if(useLocal){
    try{
      setAIStatus(els.nowAIStatus, "Loading local model… (first time can take a while)", "status-busy");
      const res = await localModelDraftNow({
        forename,
        barrier,
        responsible: responsible || "Participant",
        targetPretty: ctx.targetPretty
      });

      if(res?.action){
        els.nowAction.value = res.action.trim();
      }
      if(res?.help) els.nowHelp.value = res.help.trim();

      renderOutput(false);
      setAIStatus(els.nowAIStatus, "Local draft inserted (you can edit).", "status-ok");
      toast("Draft added.");
      return;
    }catch(err){
      console.warn("Local model draft failed, falling back:", err);
      setAIStatus(els.nowAIStatus, "Local model unavailable — using instant draft.", "status-warn");
    }
  }

  const s = bestNowSuggestion(barrier, els.nowSuggestQuery.value);
  const rawAction = resolvePlaceholders(s.action, ctx);
  const action = forenameWillify(rawAction, forename);
  const help = resolvePlaceholders(s.help, ctx);

  // If responsible is set and the action says “send it to me”, adjust lightly.
  let finalAction = action;
  if(responsible && /\bsend it to me\b/i.test(finalAction) && !/\bI\b|advisor/i.test(responsible.toLowerCase())){
    finalAction = finalAction.replace(/\bsend it to me\b/i, "save it and bring it to our next meeting");
  }

  els.nowAction.value = finalAction.trim();
  if(help) els.nowHelp.value = help.trim();

  renderOutput(false);
  setAIStatus(els.nowAIStatus, "Draft inserted (you can edit).", "status-ok");
  toast("Draft added.");
}


function loadList(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    if(!raw) return fallback;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : fallback;
  }catch{
    return fallback;
  }
}
function saveList(key, list){
  localStorage.setItem(key, JSON.stringify(list));
}

let barriers = loadList(STORAGE.barriers, DEFAULT_BARRIERS);
let timescales = loadList(STORAGE.timescales, DEFAULT_TIMESCALES);
let history = loadList(STORAGE.history, []);

const els = {
  tabNow: $("tabNow"),
  tabFuture: $("tabFuture"),
  panelNow: $("panelNow"),
  panelFuture: $("panelFuture"),

  // Now
  nowDate: $("nowDate"),
  nowDateHint: $("nowDateHint"),
  nowForename: $("nowForename"),
  nowBarrier: $("nowBarrier"),
  nowAction: $("nowAction"),
  nowResponsible: $("nowResponsible"),
  nowHelp: $("nowHelp"),
  nowTimescale: $("nowTimescale"),
  nowSuggestQuery: $("nowSuggestQuery"),
  nowSuggestList: $("nowSuggestList"),
  btnAIDraftNow: $("btnAIDraftNow"),
  nowAIStatus: $("nowAIStatus"),

  // Future
  futureDate: $("futureDate"),
  futureDateHint: $("futureDateHint"),
  futureForename: $("futureForename"),
  futureBarrier: $("futureBarrier"),
  futureReason: $("futureReason"),
  futureTimescale: $("futureTimescale"),
  futureSuggestList: $("futureSuggestList"),
  futureAIStatus: $("futureAIStatus"),
  btnAIDraftFuture: $("btnAIDraftFuture"),

  // Shared
  barrierList: $("barrierList"),
  recentNamesList: $("recentNamesList"),
  output: $("output"),

  // Buttons
  btnGenerate: $("btnGenerate"),
  btnCopy: $("btnCopy"),
  btnDownload: $("btnDownload"),
  btnClear: $("btnClear"),
  btnSave: $("btnSave"),

  // History
  historyList: $("historyList"),
  historySearch: $("historySearch"),
  btnClearHistory: $("btnClearHistory"),
  btnExport: $("btnExport"),
  btnExportCSV: $("btnExportCSV"),
  importFile: $("importFile"),

  // Modals
  btnHelp: $("btnHelp"),
  modalHelp: $("modalHelp"),
  helpBody: $("helpBody"),
  btnCloseHelp: $("btnCloseHelp"),

  btnSettings: $("btnSettings"),
  modalSettings: $("modalSettings"),
  btnCloseSettings: $("btnCloseSettings"),
  settingsBarriers: $("settingsBarriers"),
  settingsTimescales: $("settingsTimescales"),
  btnResetBarriers: $("btnResetBarriers"),
  btnSaveBarriers: $("btnSaveBarriers"),
  btnResetTimescales: $("btnResetTimescales"),
  btnSaveTimescales: $("btnSaveTimescales"),
  offlineStatus: $("offlineStatus"),
  btnInstallHint: $("btnInstallHint"),
  btnResetOfflineCache: $("btnResetOfflineCache"),

  // AI settings
  toggleExperimentalModel: $("toggleExperimentalModel"),
  modelSupportPill: $("modelSupportPill"),
  modelSupportNote: $("modelSupportNote"),
};

function activeMode(){
  return els.tabNow.classList.contains("active") ? "now" : "future";
}

function setTab(mode){
  const isNow = mode === "now";
  els.tabNow.classList.toggle("active", isNow);
  els.tabFuture.classList.toggle("active", !isNow);

  els.tabNow.setAttribute("aria-selected", String(isNow));
  els.tabFuture.setAttribute("aria-selected", String(!isNow));
  
  // Focus management for accessibility
  const firstInput = isNow ? els.nowDate : els.futureDate;
  setTimeout(() => firstInput?.focus(), 50);
  
  // Clear validation when switching tabs
  clearValidation();

  els.panelNow.classList.toggle("hidden", !isNow);
  els.panelFuture.classList.toggle("hidden", isNow);

  renderOutput(); // keep preview consistent
}

function populateDatalist(){
  els.barrierList.innerHTML = "";
  barriers.forEach(b => {
    const opt = document.createElement("option");
    opt.value = b;
    els.barrierList.appendChild(opt);
  });
}

function populateTimescales(){
  const fill = (sel) => {
    sel.innerHTML = "<option value='' disabled selected>Select timescale…</option>";
    timescales.forEach(t => {
      const o = document.createElement("option");
      o.value = t;
      o.textContent = t;
      sel.appendChild(o);
    });
  };
  fill(els.nowTimescale);
  fill(els.futureTimescale);
}

function dateHintNow(dateEl, hintEl){
  const t = todayISO();
  if(!dateEl.value){
    hintEl.textContent = "";
    hintEl.classList.remove("warn");
    return;
  }
  if(dateEl.value !== t){
    hintEl.textContent = `Note: the spreadsheet flags a warning if this isn't today (${t}).`;
    hintEl.classList.add("warn");
  }else{
    hintEl.textContent = "";
    hintEl.classList.remove("warn");
  }
}

function dateHintFuture(dateEl, hintEl){
  const t = todayISO();
  if(!dateEl.value){
    hintEl.textContent = "";
    hintEl.classList.remove("warn");
    return;
  }
  if(dateEl.value < t){
    hintEl.textContent = `Date is in the past. Task-based actions should be for future activities.`;
    hintEl.classList.add("warn");
  }else{
    hintEl.textContent = "";
    hintEl.classList.remove("warn");
  }
}

function validateNow(){
  const required = [
    els.nowDate.value,
    els.nowForename.value.trim(),
    els.nowBarrier.value.trim(),
    els.nowAction.value.trim(),
    els.nowResponsible.value.trim(),
    els.nowHelp.value.trim(),
    els.nowTimescale.value
  ];
  return required.every(Boolean);
}

function validateFuture(){
  const required = [
    els.futureDate.value,
    els.futureForename.value.trim(),
    els.futureBarrier.value.trim(),
    els.futureReason.value.trim(),
    els.futureTimescale.value
  ];
  return required.every(Boolean);
}

function buildNow(){
  // SMART format for Restart Advisors
  const date = formatDDMMMYY(els.nowDate.value);
  const forename = els.nowForename.value.trim();
  const barrier = els.nowBarrier.value.trim();
  const action = els.nowAction.value.trim().replace(/\s+/g, " ");
  const responsible = els.nowResponsible.value.trim();
  const help = els.nowHelp.value.trim().replace(/\s+/g, " ");
  const timescale = els.nowTimescale.value;

  // Format action - remove duplicate name if action already starts with forename
  let formattedAction = action;
  const lowerAction = formattedAction.toLowerCase();
  const lowerName = forename.toLowerCase();
  
  // Check if action already starts with "[name] will" pattern and remove it
  const nameWillPattern = new RegExp(`^${lowerName}\\s+will\\s+`, 'i');
  if (nameWillPattern.test(formattedAction)) {
    formattedAction = formattedAction.replace(nameWillPattern, '');
  }
  
  // Ensure action starts with lowercase
  if (formattedAction) {
    formattedAction = formattedAction.charAt(0).toLowerCase() + formattedAction.slice(1);
  }

  return [
    `${BUILDER_NOW.p1} ${date}, ${forename} and I ${BUILDER_NOW.p2} ${barrier}.`,
    `${BUILDER_NOW.p3} ${forename} will ${formattedAction}`,
    `${BUILDER_NOW.p5} ${help}.`,
    `${BUILDER_NOW.p6}`,
    `${BUILDER_NOW.p7} ${timescale}.`
  ].join(" ");
}

function formatTaskOutcome(forename, rawOutcome) {
  let outcome = (rawOutcome || "").trim().replace(/\s+/g, " ");
  if (!outcome) return "";
  
  // Remove trailing period (we add our own)
  if (outcome.endsWith(".")) {
    outcome = outcome.slice(0, -1);
  }
  
  const lowerOutcome = outcome.toLowerCase();
  const lowerName = (forename || "").toLowerCase();
  const name = forename || "They";
  
  // Check if outcome already starts with participant name (case-insensitive)
  if (lowerName && lowerOutcome.startsWith(lowerName + " ")) {
    // Already has participant name - just ensure first letter is capitalised
    return forename + outcome.slice(lowerName.length);
  }
  
  // Check if starts with pronoun
  if (/^(they|he|she)\s/i.test(outcome)) {
    return outcome.charAt(0).toUpperCase() + outcome.slice(1);
  }
  
  // Check if it starts with "will" - prefix with participant name
  if (/^will\s/i.test(outcome)) {
    return `${name} ${outcome.charAt(0).toLowerCase() + outcome.slice(1)}`;
  }
  
  // Check if it starts with a verb (assume future action, prefix with "[Name] will")
  const startsWithVerb = /^(speak|attend|complete|submit|practise|practice|review|participate|collect|hand|receive|prepare|create|discuss|identify|make|apply|learn|meet|call|book|gather|research|write|contact|take|engage|work|visit|follow|organise|organize|arrange|ask|bring|check|confirm|email|find|get|go|help|look|phone|read|register|search|send|sign|talk|update|upload|use)/i.test(outcome);
  if (startsWithVerb) {
    return `${name} will ${outcome.charAt(0).toLowerCase() + outcome.slice(1)}`;
  }
  
  // Default: capitalise as-is (it's likely already a complete sentence)
  return outcome.charAt(0).toUpperCase() + outcome.slice(1);
}

function buildFuture(){
  // Task-based output format
  const date = formatDDMMMYY(els.futureDate.value);
  const forename = els.futureForename.value.trim();
  const task = els.futureBarrier.value.trim().replace(/\s+/g, " ");
  const rawOutcome = els.futureReason.value.trim();
  const timescale = els.futureTimescale.value;
  
  const formattedOutcome = formatTaskOutcome(forename, rawOutcome);

  return [
    `${BUILDER_TASK.p1} ${date}, ${forename} ${BUILDER_TASK.p2} ${task}.`,
    `${formattedOutcome}.`,
    `${BUILDER_TASK.p4} ${timescale}.`
  ].join(" ");
}

function highlightValidation(mode) {
  if (mode === "now") {
    const fields = [
      { el: els.nowDate, valid: !!els.nowDate.value },
      { el: els.nowForename, valid: !!els.nowForename.value.trim() },
      { el: els.nowBarrier, valid: !!els.nowBarrier.value.trim() },
      { el: els.nowAction, valid: !!els.nowAction.value.trim() },
      { el: els.nowResponsible, valid: !!els.nowResponsible.value },
      { el: els.nowHelp, valid: !!els.nowHelp.value.trim() },
      { el: els.nowTimescale, valid: !!els.nowTimescale.value }
    ];
    fields.forEach(({ el, valid }) => {
      el.classList.toggle("invalid", !valid);
      el.classList.toggle("valid", valid);
    });
  } else {
    const fields = [
      { el: els.futureDate, valid: !!els.futureDate.value },
      { el: els.futureForename, valid: !!els.futureForename.value.trim() },
      { el: els.futureBarrier, valid: !!els.futureBarrier.value.trim() },
      { el: els.futureReason, valid: !!els.futureReason.value.trim() },
      { el: els.futureTimescale, valid: !!els.futureTimescale.value }
    ];
    fields.forEach(({ el, valid }) => {
      el.classList.toggle("invalid", !valid);
      el.classList.toggle("valid", valid);
    });
  }
}

function clearValidation() {
  const allFields = [
    els.nowDate, els.nowForename, els.nowBarrier, els.nowAction, 
    els.nowResponsible, els.nowHelp, els.nowTimescale,
    els.futureDate, els.futureForename, els.futureBarrier, 
    els.futureReason, els.futureTimescale
  ];
  allFields.forEach(el => {
    el.classList.remove("invalid", "valid");
  });
}

function renderOutput(forceGenerate=false){
  const mode = activeMode();
  const ok = mode === "now" ? validateNow() : validateFuture();
  
  if(forceGenerate) {
    highlightValidation(mode);
  }
  
  if(!ok){
    els.output.textContent = forceGenerate
      ? "Please complete all the above boxes to generate an action."
      : "";
    return;
  }
  els.output.textContent = mode === "now" ? buildNow() : buildFuture();
  announce("Action generated");
}

async function copyOutput(){
  const text = els.output.textContent.trim();
  if(!text) return toast("Nothing to copy yet.");
  try{
    await navigator.clipboard.writeText(text);
    // Visual feedback
    els.output.classList.add("copied");
    setTimeout(() => els.output.classList.remove("copied"), 400);
    toast("Copied to clipboard.");
    announce("Copied to clipboard");
  }catch{
    // fallback
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position="fixed";
    ta.style.opacity="0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
    els.output.classList.add("copied");
    setTimeout(() => els.output.classList.remove("copied"), 400);
    toast("Copied to clipboard.");
    announce("Copied to clipboard");
  }
}

function downloadTxt(){
  const text = els.output.textContent.trim();
  if(!text) return toast("Nothing to download yet.");
  const blob = new Blob([text], {type:"text/plain;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `smart-action-${activeMode()}-${new Date().toISOString().slice(0,10)}.txt`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function clearForms(){
  // Keep dates defaulted to today
  els.nowForename.value="";
  els.nowBarrier.value="";
  els.nowAction.value="";
  els.nowResponsible.value="";
  els.nowHelp.value="";
  els.nowTimescale.value="";

  els.futureForename.value="";
  els.futureBarrier.value="";
  els.futureReason.value="";
  els.futureTimescale.value="";

  clearValidation();
  renderOutput();
}

function saveToHistory(){
  const text = els.output.textContent.trim();
  if(!text) return toast("Generate something first.");
  const mode = activeMode();
  
  // Save forename to recent names
  const forename = mode === "now" ? els.nowForename.value.trim() : els.futureForename.value.trim();
  if(forename) addRecentName(forename);

  const item = {
    id: crypto.randomUUID(),
    mode,
    createdAt: new Date().toISOString(),
    text,
    meta: mode === "now"
      ? {
          date: els.nowDate.value,
          forename: els.nowForename.value.trim(),
          barrier: els.nowBarrier.value.trim(),
          timescale: els.nowTimescale.value
        }
      : {
          date: els.futureDate.value,
          forename: els.futureForename.value.trim(),
          barrier: els.futureBarrier.value.trim(),
          timescale: els.futureTimescale.value
        }
  };

  history.unshift(item);
  history = history.slice(0, 100); // keep it tidy
  localStorage.setItem(STORAGE.history, JSON.stringify(history));
  renderHistory();
  toast("Saved.");
}

function renderHistory(searchQuery = ""){
  els.historyList.innerHTML = "";
  const query = searchQuery.toLowerCase().trim();
  
  const filtered = query 
    ? history.filter(h => 
        h.text.toLowerCase().includes(query) ||
        (h.meta?.forename || "").toLowerCase().includes(query) ||
        (h.meta?.barrier || "").toLowerCase().includes(query)
      )
    : history;
  
  if(!filtered.length){
    const empty = document.createElement("div");
    empty.className="item";
    empty.innerHTML = query 
      ? "<div class='meta'>No matching items found.</div>"
      : "<div class='meta'>No saved items yet.</div>";
    els.historyList.appendChild(empty);
    return;
  }

  const fragment = document.createDocumentFragment();
  filtered.forEach(h => {
    const div = document.createElement("div");
    div.className = "item";

    const dt = new Date(h.createdAt);
    const pretty = dt.toLocaleString("en-GB", { dateStyle:"medium", timeStyle:"short" });

    const meta = [
      `${h.mode === "now" ? "Barrier to action" : "Task-based"}`,
      `Saved: ${pretty}`,
      h.meta?.forename ? `Name: ${escapeHtml(h.meta.forename)}` : "",
      h.meta?.barrier ? `${h.mode === "now" ? "Barrier" : "Task"}: ${escapeHtml(h.meta.barrier)}` : "",
      h.meta?.timescale ? `Timescale: ${escapeHtml(h.meta.timescale)}` : ""
    ].filter(Boolean).map(t => `<span>${t}</span>`).join("<span>•</span>");

    div.innerHTML = `
      <div class="meta">${meta}</div>
      <div class="text">${escapeHtml(h.text)}</div>
      <div class="row">
        <button class="btn small" data-act="edit" data-id="${h.id}" type="button">Edit</button>
        <button class="btn small ghost" data-act="copy" data-id="${h.id}" type="button">Copy</button>
        <button class="btn small danger" data-act="delete" data-id="${h.id}" type="button">Delete</button>
      </div>
    `;
    fragment.appendChild(div);
  });
  els.historyList.appendChild(fragment);
}

function escapeHtml(str){
  return str.replace(/[&<>"']/g, (m) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"
  }[m]));
}

function handleHistoryClick(e){
  const btn = e.target.closest("button[data-act]");
  if(!btn) return;
  const id = btn.getAttribute("data-id");
  const act = btn.getAttribute("data-act");
  const item = history.find(x => x.id === id);
  if(!item) return;

  if(act === "copy"){
    navigator.clipboard.writeText(item.text).then(()=>toast("Copied.")).catch(()=>toast("Couldn’t copy."));
  }
  if(act === "edit"){
    // Load all available fields and restore the generated text
    if(item.mode === "now"){
      setTab("now");
      els.nowDate.value = item.meta.date || todayISO();
      els.nowForename.value = item.meta.forename || "";
      els.nowBarrier.value = item.meta.barrier || "";
      els.nowTimescale.value = item.meta.timescale || "";
    }else{
      setTab("future");
      els.futureDate.value = item.meta.date || todayISO();
      els.futureForename.value = item.meta.forename || "";
      els.futureBarrier.value = item.meta.barrier || "";
      els.futureTimescale.value = item.meta.timescale || "";
    }
    dateHintNow(els.nowDate, els.nowDateHint);
    dateHintFuture(els.futureDate, els.futureDateHint);
    buildNowSuggestionList();
    clearValidation();
    els.output.textContent = item.text || "";
    toast("Loaded. You can edit and regenerate.");
    announce("Loaded for editing");
  }
  if(act === "delete"){
    history = history.filter(x => x.id !== id);
    localStorage.setItem(STORAGE.history, JSON.stringify(history));
    renderHistory(els.historySearch?.value || "");
    toast("Deleted.");
    announce("Deleted from history");
  }
}

function exportHistory(){
  const payload = { version: 1, exportedAt: new Date().toISOString(), history, barriers, timescales };
  const blob = new Blob([JSON.stringify(payload, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `smart-action-export-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function csvEscape(val) {
  const s = String(val || "");
  // Replace newlines with space and escape quotes
  const cleaned = s.replace(/[\r\n]+/g, " ").replace(/"/g, '""');
  return `"${cleaned}"`;
}

function exportHistoryCSV(){
  if(!history.length) return toast("No history to export.");
  
  const headers = ["Date", "Type", "Forename", "Barrier/Task", "Timescale", "Text"];
  const rows = history.map(h => [
    csvEscape(h.meta?.date),
    csvEscape(h.mode === "now" ? "Barrier to action" : "Task-based"),
    csvEscape(h.meta?.forename),
    csvEscape(h.meta?.barrier),
    csvEscape(h.meta?.timescale),
    csvEscape(h.text)
  ]);
  
  const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
  const blob = new Blob([csv], {type:"text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `smart-action-history-${new Date().toISOString().slice(0,10)}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  toast("CSV exported.");
}

function importHistory(file){
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const data = JSON.parse(String(reader.result || "{}"));
      if(Array.isArray(data.history)) history = data.history;
      if(Array.isArray(data.barriers)) barriers = data.barriers;
      if(Array.isArray(data.timescales)) timescales = data.timescales;

      saveList(STORAGE.barriers, barriers);
      saveList(STORAGE.timescales, timescales);
      localStorage.setItem(STORAGE.history, JSON.stringify(history));

      populateDatalist();
      populateTimescales();
      renderHistory();
      toast("Import complete.");
    }catch{
      toast("That file didn’t look like an export from this app.");
    }
  };
  reader.readAsText(file);
}

function showGuidance(){
  const html = GUIDANCE.map(g => {
    const body = Array.isArray(g.body)
      ? "<ul>" + g.body.map(x => `<li>${escapeHtml(x)}</li>`).join("") + "</ul>"
      : `<p>${escapeHtml(g.body)}</p>`;
    return `<div class="card"><div class="card-title">${escapeHtml(g.title)}</div><div class="card-sub">${body}</div></div>`;
  }).join("");
  els.helpBody.innerHTML = html;
  els.modalHelp.showModal();
}

function showSettings(){
  els.settingsBarriers.value = barriers.join("\n");
  els.settingsTimescales.value = timescales.join("\n");
  if(els.toggleExperimentalModel){
    els.toggleExperimentalModel.checked = getExperimentalModelEnabled();
  }
  updateModelSupportUI();
  els.modalSettings.showModal();
}

function saveSettingsBarriers(){
  const list = els.settingsBarriers.value
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean);

  if(!list.length) return toast("Barriers list can’t be empty.");
  barriers = Array.from(new Set(list));
  saveList(STORAGE.barriers, barriers);
  populateDatalist();
  toast("Barriers saved.");
}

function saveSettingsTimescales(){
  const list = els.settingsTimescales.value
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean);

  if(!list.length) return toast("Timescales can’t be empty.");
  timescales = Array.from(new Set(list));
  saveList(STORAGE.timescales, timescales);
  populateTimescales();
  toast("Timescales saved.");
}

function resetBarriers(){
  barriers = [...DEFAULT_BARRIERS];
  saveList(STORAGE.barriers, barriers);
  populateDatalist();
  els.settingsBarriers.value = barriers.join("\n");
  toast("Reset barriers.");
}
function resetTimescales(){
  timescales = [...DEFAULT_TIMESCALES];
  saveList(STORAGE.timescales, timescales);
  populateTimescales();
  els.settingsTimescales.value = timescales.join("\n");
  toast("Reset timescales.");
}

function toast(msg){
  // iOS Safari bottom toolbars can cover bottom-fixed toasts, so we pin to the top.
  const t = document.createElement("div");
  t.textContent = msg;
  t.style.position = "fixed";
  t.style.left = "50%";
  t.style.top = "calc(env(safe-area-inset-top, 0px) + 14px)";
  t.style.transform = "translateX(-50%)";
  t.style.maxWidth = "min(92vw, 520px)";
  t.style.padding = "10px 12px";
  t.style.border = "1px solid rgba(255,255,255,.14)";
  t.style.background = "rgba(10,14,25,.92)";
  t.style.borderRadius = "999px";
  t.style.backdropFilter = "blur(12px)";
  t.style.boxShadow = "0 12px 40px rgba(0,0,0,.45)";
  t.style.zIndex = "99999";
  t.style.pointerEvents = "none";
  document.body.appendChild(t);
  setTimeout(()=>t.remove(), 2400);
}

function installHint(){
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const text = isIOS
    ? "On iPhone/iPad: Share → Add to Home Screen. After first load it can work offline."
    : "On desktop/Android: use your browser’s Install / Add to Home Screen option (often in the menu).";
  alert(text);
}

function updateOfflineStatus(){
  const online = navigator.onLine;
  els.offlineStatus.textContent = online ? "Online" : "Offline";
}

function updateModelSupportUI(){
  if(!els.modelSupportPill) return;

  if(IS_IOS){
    els.modelSupportPill.textContent = "iOS: instant drafts";
    if(els.modelSupportNote) els.modelSupportNote.textContent = "On iPhone/iPad, AI draft always uses instant offline templates (more reliable than loading a local model).";
    if(els.toggleExperimentalModel){
      els.toggleExperimentalModel.checked = false;
      els.toggleExperimentalModel.disabled = true;
    }
    setExperimentalModelEnabled(false);
    return;
  }

  const supported = localModelSupported();
  els.modelSupportPill.textContent = supported ? "Supported" : "Not supported";
  if(els.toggleExperimentalModel) els.toggleExperimentalModel.disabled = !supported;
  if(els.modelSupportNote){
    els.modelSupportNote.textContent = supported
      ? "When enabled, AI draft will try to load a small local model (first use downloads model files). If it fails, it falls back to instant drafts."
      : "Your browser doesn’t appear to support this experimental feature. Instant drafts will still work.";
  }
}

async function resetOfflineCache(){
  const ok = confirm("Reset offline cache?\n\nThis clears the app’s stored offline files so you get the latest version. Your saved history will NOT be removed.");
  if(!ok) return;

  try{
    if("serviceWorker" in navigator){
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
    if("caches" in window){
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
  }catch(_){}

  toast("Offline cache reset. Reloading…");
  const url = new URL(location.href);
  url.searchParams.set("v", String(Date.now()));
  location.href = url.toString();
}


function init(){
  // default dates to today
  const t = todayISO();
  els.nowDate.value = t;
  els.futureDate.value = t;
  // "Barrier to action now" should be today only, but Task-based allows future dates
  els.nowDate.max = t;
  els.futureDate.min = t; // Task-based must be today or future

  populateDatalist();
  populateTimescales();
  populateRecentNamesList();
  renderHistory();
  buildNowSuggestionList();

  // tabs
  els.tabNow.addEventListener("click", ()=>setTab("now"));
  els.tabFuture.addEventListener("click", ()=>setTab("future"));

  // Debounced handlers for performance
  const debouncedRender = debounce(() => renderOutput(false), 100);
  const debouncedSuggestions = debounce(buildNowSuggestionList, 100);

  // live output (debounced for text inputs, immediate for selects)
  [els.nowForename, els.nowBarrier, els.nowAction, els.nowHelp, els.futureForename, els.futureBarrier, els.futureReason]
    .forEach(el => el.addEventListener("input", debouncedRender, { passive: true }));
  
  [els.nowDate, els.nowResponsible, els.nowTimescale, els.futureDate, els.futureTimescale]
    .forEach(el => el.addEventListener("change", () => renderOutput(false)));

  // suggestions update (debounced)
  [els.nowBarrier, els.nowSuggestQuery].forEach(el => el.addEventListener("input", debouncedSuggestions, { passive: true }));
  [els.nowDate, els.nowTimescale].forEach(el => el.addEventListener("change", buildNowSuggestionList));


  // date hints
  els.nowDate.addEventListener("change", ()=>dateHintNow(els.nowDate, els.nowDateHint));
  els.futureDate.addEventListener("change", ()=>dateHintFuture(els.futureDate, els.futureDateHint));
  dateHintNow(els.nowDate, els.nowDateHint);
  dateHintFuture(els.futureDate, els.futureDateHint);

  // buttons
  els.btnGenerate.addEventListener("click", ()=>renderOutput(true));
  els.btnAIDraftNow.addEventListener("click", aiDraftNow);
  els.btnAIDraftFuture?.addEventListener("click", aiDraftFuture);
  
  // Build task-based suggestions when task description changes
  const debouncedFutureSuggestions = debounce(buildFutureSuggestionList, 100);
  els.futureBarrier?.addEventListener("input", debouncedFutureSuggestions, { passive: true });
  buildFutureSuggestionList();
  els.btnCopy.addEventListener("click", copyOutput);
  els.btnDownload.addEventListener("click", downloadTxt);
  els.btnClear.addEventListener("click", clearForms);
  els.btnSave.addEventListener("click", saveToHistory);

  // history
  els.historyList.addEventListener("click", handleHistoryClick);
  els.btnClearHistory.addEventListener("click", ()=>{
    history = [];
    localStorage.setItem(STORAGE.history, JSON.stringify(history));
    renderHistory();
    toast("History cleared.");
  });
  els.btnExport.addEventListener("click", exportHistory);
  els.btnExportCSV?.addEventListener("click", exportHistoryCSV);
  els.importFile.addEventListener("change", (e)=>{
    const f = e.target.files?.[0];
    if(f) importHistory(f);
    e.target.value="";
  });
  
  // History search
  const debouncedHistorySearch = debounce(() => renderHistory(els.historySearch?.value || ""), 150);
  els.historySearch?.addEventListener("input", debouncedHistorySearch, { passive: true });

  // Keyboard shortcuts (only when not in modal or input with default shortcuts)
  document.addEventListener("keydown", (e) => {
    // Skip if a modal is open
    if (els.modalHelp?.open || els.modalSettings?.open) return;
    
    // Ctrl+Enter or Cmd+Enter to generate
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      e.preventDefault();
      const mode = activeMode();
      const ok = mode === "now" ? validateNow() : validateFuture();
      renderOutput(true);
      if (ok) toast("Generated.");
    }
    // Ctrl+Shift+C or Cmd+Shift+C to copy output
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "c") {
      e.preventDefault();
      copyOutput();
    }
  });

  // guidance modal
  els.btnHelp.addEventListener("click", showGuidance);
  els.btnCloseHelp.addEventListener("click", ()=>els.modalHelp.close());

  // settings modal
  els.btnSettings.addEventListener("click", ()=>{
    updateOfflineStatus();
    showSettings();
  });
  els.btnCloseSettings.addEventListener("click", ()=>els.modalSettings.close());
  els.btnSaveBarriers.addEventListener("click", saveSettingsBarriers);
  els.btnSaveTimescales.addEventListener("click", saveSettingsTimescales);
  els.btnResetBarriers.addEventListener("click", resetBarriers);
  els.btnResetTimescales.addEventListener("click", resetTimescales);
  els.btnInstallHint.addEventListener("click", installHint);
  els.btnResetOfflineCache?.addEventListener("click", resetOfflineCache);

  // AI settings
  els.toggleExperimentalModel?.addEventListener("change", ()=>{
    const v = !!els.toggleExperimentalModel.checked;
    setExperimentalModelEnabled(v);
    updateModelSupportUI();
    toast(v ? "Experimental local model enabled." : "Experimental local model disabled.");
  });

  // offline status
  window.addEventListener("online", updateOfflineStatus);
  window.addEventListener("offline", updateOfflineStatus);
  updateOfflineStatus();
  updateModelSupportUI();

  // PWA service worker (optional)
  if("serviceWorker" in navigator){
    navigator.serviceWorker.register("./sw.js").catch(()=>{});
  }
  window.__APP_READY = true;
}

init();
// Expose AI draft handlers for inline onclick fallback
window.__aiDraftNow = () => aiDraftNow();
window.__aiDraftFuture = () => aiDraftFuture();
