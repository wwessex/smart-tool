# SMART Action Support Tool (Web App)

This is a rebuild of **Restart SMART Action Tool v1.xlsm** as a modern, fast **static web app**.

## What it does

It mirrors the spreadsheet behaviour:

- **Barrier to action now**
  - Uses the same barriers list + timescales
  - Generates the same wording structure as the spreadsheet's `Generated Action`
- **Barrier to action in future**
  - Same barrier list + timescales
  - Generates the same wording structure

Extras (web-only):

- One-click **Copy** to clipboard
- **Download** as `.txt`
- **History** saved locally in your browser (no server needed)
- Export/import as JSON
- Optional offline/PWA support (service worker)

## Upload (no build step)

You can upload this folder directly to any web host (cPanel, shared hosting, etc.).

1. Upload everything in this folder (keep the structure).
2. Visit `index.html` in your browser.

### If uploading to a subfolder

Example: `https://example.com/smart-actions/`

Upload the files into that folder, then open the URL.

## Notes

- The spreadsheet warns when meeting date isn't **today** — this app shows the same warning as a note, but still allows you to proceed.
- Spellcheck is enabled on the text areas; always proofread before pasting into ICONI.

## Disable offline features (optional)

If you don't want PWA/offline:

- Delete `sw.js` and `manifest.webmanifest`
- Remove the `<link rel="manifest" ...>` line in `index.html`


## Advisor assist (mixed strategy)

The app provides two layers of help:

1. **Instant suggestions (offline):** Curated action/reason templates appear as clickable chips when you select a barrier.
2. **AI draft (optional, on-device):** Tap **AI draft** to generate a draft action/benefit (or future reason). This runs **client-side in your browser** using Transformers.js and open-weights models.

### Notes
- First use will download model files to the browser cache (size depends on device + backend).
- If AI fails on a device/network, the instant suggestions still work.
- The generated boilerplate text remains deterministic; AI only fills the free-text fields.
