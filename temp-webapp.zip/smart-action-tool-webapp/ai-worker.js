// AI Worker (module) - runs fully client-side using Transformers.js
import { pipeline, env } from "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1";

// Prefer browser cache where available (reduces repeat downloads)
env.useBrowserCache = true;
env.allowRemoteModels = true;
// Keep local model loading off by default; this app is static-hosted without /models
env.allowLocalModels = false;

let text2text = null;
let loading = null;

function status(message, level="status-busy"){
  postMessage({ type: "status", message, level });
}

async function loadModel(){
  if(text2text) return text2text;
  if(loading) return loading;
  loading = (async ()=>{
    status("Loading AI model (first use may take a moment)…", "status-busy");
    // flan-t5-small is a good quality/size balance for structured text completion.
    // Use quantized weights for WASM performance.
    text2text = await pipeline("text2text-generation", "Xenova/flan-t5-small", {
      dtype: "q8"
    });
    status("AI model loaded.", "status-ok");
    postMessage({ type: "ready" });
    return text2text;
  })();
  return loading;
}

async function gen(prompt, opts={}){
  const pipe = await loadModel();
  const out = await pipe(prompt, {
    max_new_tokens: opts.max_new_tokens ?? 80,
    temperature: opts.temperature ?? 0.3,
    top_p: opts.top_p ?? 0.9,
    repetition_penalty: 1.05
  });
  const text = (out?.[0]?.generated_text || "").trim();
  return text.replace(/^"|"$/g, "").trim();
}

function cleanSentence(s){
  return (s || "")
    .replace(/\s+/g, " ")
    .replace(/\s+([\.,;:!\?])/g, "$1")
    .trim();
}

self.addEventListener("message", async (e)=>{
  const msg = e.data || {};
  const id = msg.id;

  try{
    if(msg.type === "init"){
      await loadModel();
      postMessage({ id, ok: true, type: "init" });
      return;
    }

    if(msg.type === "draft_now"){
      const { barrier, forename, responsible, targetPretty } = msg;

      status("Drafting action…", "status-busy");
      const actionPrompt =
`You are helping an employment advisor write a SMART action.

Write ONE action sentence for ${forename} about the barrier: "${barrier}".

Requirements:

- UK English.

- Start with a verb.

- Be specific and realistic.

- Include a clear deadline of ${targetPretty}.

- Mention where/how only if useful.

Output ONLY the action sentence.`;
      let action = await gen(actionPrompt, { max_new_tokens: 70 });
      action = cleanSentence(action);
      // Ensure deadline mention
      if(action && !action.toLowerCase().includes(targetPretty.toLowerCase())){
        action = cleanSentence(action + " by " + targetPretty + ".");
      }
      if(action && !/[\.!\?]$/.test(action)) action += ".";

      status("Drafting benefit…", "status-busy");
      const helpPrompt =
`Write a short phrase that can directly follow the words: "This action will help".

Context: barrier is "${barrier}".

Rules:

- Do NOT repeat the words "This action will help".

- Do NOT include the participant's name.

- Keep under 18 words.

- Plain UK English.

Output ONLY the phrase.`;
      let help = await gen(helpPrompt, { max_new_tokens: 45 });
      help = cleanSentence(help);
      // If model accidentally returned a full sentence, strip leading clause.
      help = help.replace(/^this action will help\s+/i, "");
      if(help && help.startsWith(".")) help = help.slice(1).trim();

      postMessage({ id, ok: true, action, help });
      return;
    }

    if(msg.type === "draft_future"){
      const { barrier, forename, targetPretty } = msg;

      status("Drafting reason…", "status-busy");
      const reasonPrompt =
`You are helping an employment advisor write a case note.

Write ONE professional sentence explaining why the barrier "${barrier}" cannot be addressed right now for ${forename}.

It MUST end by saying it will be reviewed in ${targetPretty}.

UK English. Output ONLY the sentence.`;
      let reason = await gen(reasonPrompt, { max_new_tokens: 70 });
      reason = cleanSentence(reason);
      if(reason && !reason.toLowerCase().includes("review")){
        reason = cleanSentence(reason + " This will be reviewed in " + targetPretty + ".");
      }else if(reason && !reason.toLowerCase().includes(targetPretty.toLowerCase())){
        reason = cleanSentence(reason + " This will be reviewed in " + targetPretty + ".");
      }
      if(reason && !/[\.!\?]$/.test(reason)) reason += ".";

      postMessage({ id, ok: true, reason });
      return;
    }

    postMessage({ id, ok: false, error: "Unknown message type." });

  }catch(err){
    postMessage({ id, ok: false, error: String(err?.message || err) });
  }
});
